
public class Shark extends Predator {

    // public int[] huntingByShark(PenguinFamily[] pFamilies, int patrolDogs) {
    //     double sharkProbability = 0.02;
    //     int countEaten[] = { 0, 0, 0, 0 };
    //     if (pFamilies != null) {
    //         for (PenguinFamily family : pFamilies) {
    //             if (family.getParents() != null) {
    //                 for (Penguin penguin : family.getParents()) {
    //                     if (penguin != null && penguin.getIsAlive()) {
    //                         if (Math.random() < sharkProbability) {
    //                             if (penguin.getIsMale())
    //                                 countEaten[0] += killPenguin(family, penguin);
    //                             else
    //                                 countEaten[1] += killPenguin(family, penguin);
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //     }
    //     return countEaten;
    // }
}