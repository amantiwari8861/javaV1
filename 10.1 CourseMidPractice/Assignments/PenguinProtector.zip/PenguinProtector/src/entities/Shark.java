package entities;

public class Shark extends Predator {
}
