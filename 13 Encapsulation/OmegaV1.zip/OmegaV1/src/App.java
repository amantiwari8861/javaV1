import institute.Handler;
import java.util.Scanner;
import java.lang.*;//imported by default

public class App 
{
    public static void main(String[] args)
    {
        //Encapsulation : wrapping the data(class or etc) into a single unit(folder)
        //tree (to see directory structure)
        //tree /f (to see directory structure with file names)

        //to compile : javac -d . Filename.java
        //to run : java package.ClassName

        Handler h=new Handler();
        h.teachStuByTeacher();
        // System.out.println(Math.sqrt(3));

        //Access Modifiers :
        //  1.public
        //  2.private
        //  3.protected
        //there is also a non access modifier called default in which no keyword is required to use this

    }
}