package institute;

import institute.cp.teacher.Teacher;

public class Handler 
{
    public void teachStuByTeacher()
    {
        Teacher t=new Teacher();
        t.teach();
    }
}