package institute.cp.student;

public class Student {
    
}
