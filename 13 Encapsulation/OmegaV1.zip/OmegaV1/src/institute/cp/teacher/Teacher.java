package institute.cp.teacher;

public class Teacher {
    
    public void teach()
    {
        System.out.println("Teaching cp students");
    }
}
