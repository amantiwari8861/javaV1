package institute.sector62.student;

public class Student {
    
}
