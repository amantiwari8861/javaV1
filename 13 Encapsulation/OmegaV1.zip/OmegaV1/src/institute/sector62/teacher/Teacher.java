package institute.sector62.teacher;

public class Teacher {
    
    public void teach()
    {
        System.out.println("Teaching sector 62 students");
    }
}
