package institute.sector62.teacher.parttime.intern;

public class Intern {
    
}
